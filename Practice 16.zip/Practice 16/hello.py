# Orest Sosnicki, CIS345, 12:00
from nameko.rpc import rpc
import time


class GreetingService:
    """Explain service"""

    name = "greet_service"

    @rpc
    def greet(self, name):
        return f"Hello {name}"

    @rpc
    def get_time(self):
        return time.ctime()
        