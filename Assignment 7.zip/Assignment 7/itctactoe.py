# Orest Sosnicki, CIS345, 12:00, A7

from tkinter import *
from tkinter import messagebox


def hit(press):
    global buttons, count, player1, player2

    if count % 2 == 0:
        player = "X"
    else:
        player = "O"

    count += 1

    buttons[press]["text"] = player
    buttons[press]["state"] = "disabled"

    if player == "X":
        player1.append(press)
        win(player1)
    else:
        player2.append(press)
        win(player2)


def win(check):
    global count, game

    game_set = False

    if count % 2 == 0:
        winner = "Player2 Wins"
    else:
        winner = "Player1 Wins"

    if 0 in check and 1 in check and 2 in check:
        game_set = True

    elif 0 in check and 4 in check and 8 in check:
        game_set = True

    elif 0 in check and 3 in check and 6 in check:
        game_set = True

    elif 1 in check and 4 in check and 7 in check:
        game_set = True

    elif 2 in check and 5 in check and 8 in check:
        game_set = True

    elif 3 in check and 4 in check and 5 in check:
        game_set = True

    elif 6 in check and 7 in check and 8 in check:
        game_set = True

    elif 2 in check and 4 in check and 6 in check:
        game_set = True

    elif count == 9:
        game_set = True
        winner = "Cats game"

    if game_set:
        messagebox.showinfo(title="winner", message=winner)
        reset()


def reset():
    global buttons, count, player1, player2
    for n in range(0, 9):
        buttons[n]["text"] = ""
        buttons[n]["state"] = "normal"

    count = 0
    player1 = []
    player2 = []


count = 0
player1 = list()
player2 = list()

game = Tk()
game.title("TicTacToe")
game.geometry("500x500")

button0 = Button(game, text="", command=lambda: hit(0), width=10, height=5)
button0.grid(row=0, column=0)

button1 = Button(game, text="", command=lambda: hit(1), width=10, height=5)
button1.grid(row=0, column=1)

button2 = Button(game, text="", command=lambda: hit(2), width=10, height=5)
button2.grid(row=0, column=2)

button3 = Button(game, text="", command=lambda: hit(3), width=10, height=5)
button3.grid(row=1, column=0)

button4 = Button(game, text="", command=lambda: hit(4), width=10, height=5)
button4.grid(row=1, column=1)

button5 = Button(game, text="", command=lambda: hit(5), width=10, height=5)
button5.grid(row=1, column=2)

button6 = Button(game, text="", command=lambda: hit(6), width=10, height=5)
button6.grid(row=2, column=0)

button7 = Button(game, text="", command=lambda: hit(7), width=10, height=5)
button7.grid(row=2, column=1)

button8 = Button(game, text="", command=lambda: hit(8), width=10, height=5)
button8.grid(row=2, column=2)

buttons = [button0, button1, button2, button3, button4, button5, button6, button7, button8]

game.mainloop()
