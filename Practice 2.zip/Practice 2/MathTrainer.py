# Orest Sosnicki, CIS345, 12:00, PE2

import os
import random

operators = ("+", "-", "*", "/")
correct = list()

enteredAnswer = str()
answer = float()
pointsEarned = 0
pointsTotal = 0
runApp = "y"

while runApp == "y":

    number1 = random.randint(1, 100)
    number2 = random.randint(1, 100)

    sign = random.choice(operators)

    pointsTotal += 1

    os.system("cls")

    print("### Math Trainer ###".center(40, " "))
    enteredAnswer = input(f"\nProblem {pointsTotal}: {number1} {sign} {number2} = ")

    if sign == "+":
        answer = number1 + number2

    elif sign == "-":
        answer = number1 - number2

    elif sign == "*":
        answer = number1 * number2

    else:
        answer = number1 / number2
        answer = round(answer, 3)

    if str(answer) == enteredAnswer:
        pointsEarned += 1
        correct.append(enteredAnswer)

    print(f"\nPoints Earned: {pointsEarned} out of {pointsTotal} Average {(pointsEarned / pointsTotal) * 100 :.2f}%")

    runApp = input("\nWould you like to try again (y/n)? ").casefold()

    if runApp != "y":
        break

print(f"\nYou scored {pointsEarned} of {pointsTotal} and got the following right: ")
for number in correct:
    print(number)
