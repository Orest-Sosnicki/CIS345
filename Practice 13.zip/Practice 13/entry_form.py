# Orest Sosnicki, CIS345, 12:00
from tkinter import *
from tkinter import ttk


class Student:
    """Student class defines common information for all students"""

    def __init__(self, first="", last="", major='CIS'):
        self.fname = first
        self.lname = last
        self.major = major

    @property
    def fname(self):
        return self.__fname.capitalize()

    @fname.setter
    def fname(self, first):
        if first.isalpha():
            self.__fname = first
        else:
            self.__fname = 'Unknown'

    @property
    def lname(self):
        return self.__lname.capitalize()

    @lname.setter
    def lname(self, last):
        if last.isalpha():
            self.__lname = last
        else:
            self.__lname = 'Unknown'

    @property
    def major(self):
        return self.__major.upper()

    @major.setter
    def major(self, major):
        if major.isalpha() and len(major) == 3:
            self.__major = major

    def __str__(self):
        """Override the string representation of a student"""
        # Use the properties or you are not executing the formatting
        return f'{self.lname}, {self.fname} - {self.major}'


class GradStudent(Student):
    """GradStudent inherits from Student to get first & last name"""

    def __init__(self, thesis, first="", last='', major='CIS'):
        """Initialize a GradStudent with first name and thesis"""
        super().__init__(first, last, major)
        self.thesis = thesis

    @property
    def thesis(self):
        return self.__thesis.capitalize()

    @thesis.setter
    def thesis(self, new_thesis):
        """Add Thesis label to entry"""
        self.__thesis = 'Thesis: ' + new_thesis

    def __str__(self):
        """Override the string representation of a student"""
        stu_info = super().__str__()
        return f'{stu_info}  {self.thesis}'


def radio_command():
    if radio_variable.get() == 1:
        thesis_entry["state"] = "disabled"
    else:
        print()
        thesis_entry["state"] = "normal"


def save_student():
    global fName, lName, thesis, majorList, edit, stud, edit_index

    if edit == False:

        if thesis_entry["state"] == "disabled":
            try:
                new_student = Student(fName.get(), lName.get(), majorText.get())
            except ValueError as error:
                print(error)

            students.append(new_student)
            students_list.insert(END, new_student)

        else:
            try:
                new_student = GradStudent(thesis.get(), fName.get(), lName.get(), majorText.get())
            except ValueError as error:
                print(error)

            students.append(new_student)
            students_list.insert(END, new_student)

        fName.set("")
        lName.set("")
        thesis.set("")
        major_combo.current(0)


    else:
        students_list.delete(edit_index)
        new_student = GradStudent(thesis.get(), fName.get(), lName.get(), majorText.get())
        students_list.insert(edit_index, new_student)
        edit = False


def edit_student(event):
    global students_list, edit, students, fName, lName, thesis, majorText, edit_index
    edit = True
    edit_index = students_list.curselection()[0]
    stud = students[edit_index]
    fName.set(stud.fname)
    lName.set(stud.lname)
    majorText.set(stud.major)
    stud.thesis(stud.thesis)




edit = False
students = list()
stud = Student()
edit_index = int()

view = Tk()

radio_color = "sky blue"
radio_variable = IntVar()

label_justify = "left"
label_width = 10

entry_width = 36
entry_justify = "left"

fName = StringVar()
lName = StringVar()
thesis = StringVar()
majorList = ("CIS", "MGN", "FIN", "WPC")
majorText = StringVar()

view.geometry("500x500")
view.title("Student Entry Form")

Label(view, text="                               ").grid(row=0, column=0)

box = Frame(view, bg="sky blue", width=300, height=80, borderwidth=1, relief=SUNKEN)
box.grid(row=0, column=1, columnspan=2, sticky=N)
box.pack_propagate(0)

disc_label = Label(box, text="Student type", bg=radio_color)
disc_label.place(x=0, y=0)

radio_student = Radiobutton(box, text="Student", value=1, indicatoron=1, bg=radio_color, variable=radio_variable,
                            command=radio_command)
radio_student.pack(side="left", padx=35)

radio_grad = Radiobutton(box, text="Graduate Student", value=2, indicatoron=1, bg=radio_color, variable=radio_variable,
                         command=radio_command)
radio_grad.pack(side="left")

# Bellow Frame -----------------------------------------------------------------------------------------
fName_label = Label(view, text="First Name:", justify=label_justify, width=label_width)
fName_label.grid(row=2, column=1)

fname_entry = Entry(view, text="", textvariable=fName, justify=entry_justify, width=entry_width)
fname_entry.grid(row=2, column=2)

lName_label = Label(view, text="Last Name:", justify=label_justify, width=label_width)
lName_label.grid(row=3, column=1)

lname_entry = Entry(view, textvariable=lName, justify=entry_justify, width=entry_width)
lname_entry.grid(row=3, column=2)

major_label = Label(view, text="Major:", justify=label_justify, width=label_width)
major_label.grid(row=4, column=1)

major_combo = ttk.Combobox(view, values=majorList, textvariable=majorText, width=33)
major_combo.grid(row=4, column=2)
major_combo.current(0)

thesis_label = Label(view, text="Thesis: ", justify=label_justify, width=label_width)
thesis_label.grid(row=5, column=1)

thesis_entry = Entry(view, textvariable=thesis, justify=entry_justify, width=entry_width, state="disabled")
thesis_entry.grid(row=5, column=2)

save_button = Button(view, text="Save Student", command=save_student)
save_button.grid(row=6, column=2, sticky="e")

inst_label = Label(view, text="(Double-Click to Edit a Student)")
inst_label.grid(row=7, column=1, columnspan=2, sticky="w")

students_list = Listbox(view, width=50)
students_list.grid(row=8, column=1, columnspan=2)
students_list.bind("<Double-Button-1>", edit_student)

view.mainloop()
