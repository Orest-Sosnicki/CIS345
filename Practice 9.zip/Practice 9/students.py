# Orest Sosnicki, CIS345, 12:00, PE9

class Student:
    def __init__(self, firstname=" ", lastname="None"):
        self.__firstname = firstname
        self.__lastname = lastname


    @property
    def firstname(self):
        return self.__firstname

    @firstname.setter
    def firstname(self,first):
        if first.isalpha() and len(first) >= 1:
            self.__firstname = first
        else:
            self.__firstname = "Unkown"


    @property
    def lastname(self):
        return self.__lastname

    @lastname.setter
    def lastname(self, last):
        if last.isalpha() and len(last) >= 1:
            self.__lastname = last
        else:
            self.__lastname = "Unkown"


    def __str__(self):
        return f"{self.__firstname}"



class GradStudent(Student):
    def __init__(self, thesis=" ", firstname=" "):
        super().__init__(firstname)
        self.__thesis = thesis

    @property
    def thesis(self):
        return self.__thesis.casefold()

    @thesis.setter
    def thesis(self, thesis):
        self.__thesis = thesis


    def __str__(self):
        super().__str__()
        return f"{fullname}\n\t{thesis}"


class PhDStudent(Student):
    def __init__(self, dissertation=" ", firstname=" "):
        super().__init__(firstname)
        self.__dissertation = dissertation

    @property
    def dissertation(self):
        return self.__dissertation.casefold()

    @dissertation.setter
    def dissertation(self, dissertation):
        self.__dissertation = dissertation


def add_student(studentType):
    """Get student data and create an object to be returned"""
    student = None
    # Get first and last name here because all students need this data

    first = input('Enter first name: ')
    last = input('Enter last name: ')



    if studentType == "S":
        student = Student(first)
        student.lastname = last
    elif studentType == "G":
        thesis = input("Enter Store Thesis: ")
        student = GradStudent(thesis.upper(),first)
        student.lastname = last
    elif studentType == "P":
        dissertation = input("Enter dissertation: ")
        student = PhDStudent(dissertation.upper(), first)
        student.lastname = last
    return student




    #TODO: Determine student type and construct an object and save in student

    #TODO: Assign last_name using our object's property then return student


# Main Function
def main():
    """Main program logic"""
    students = []
    entry = ''
    print("{:^50}".format('Student Management System'))

    while entry != 'X':
        studentTypes = ['S', 'G', 'P']
        # Get user entry and capitalize the entry
        entry = input(
            '\nEnter (S)tudent, (G)radStudent, (P)hDStudent or (X)exit: ')
        entry = entry.upper()

        if entry == "S" or entry == "G" or entry == "P":
            students.append(add_student(entry))
        #TODO: Is user entry one of studentTypes. Yes - add_student to list


    #TODO: print students and dissertation if the student is a PhD type
    for s in students:
        print(s.firstname,s.lastname)

        if isinstance(s, GradStudent):
            print(f"\tThesis: {s.thesis}")
        elif isinstance(s, PhDStudent):
            print(f"\tDissertation: {s.dissertation}")

    print("\nThe following students were added...")


if __name__ == "__main__":
    # call and execute the main function
    main()
