# Orest Sosnicki, CIS345, 12:00, A1

import os

courseGrades = ({"Exercise": {"Total": 142.00, "Earned": 0.0, "Weight": 3, "Grade": 0.0},
                 "Assignment": {"Total": 196.00, "Earned": 0.0, "Weight": 10, "Grade": 0.0},
                 "Project": {"Total": 81.00, "Earned": 0.0, "Weight": 17, "Grade": 0.0},
                 "Quiz": {"Total": 59.00, "Earned": 0.0, "Weight": 25, "Grade": 0.0},
                 "Exam": {"Total": 166.00, "Earned": 0.0, "Weight": 36, "Grade": 0.0},
                 "Final": {"Total": 96.00, "Earned": 0.0, "Weight": 9, "Grade": 0.0}})

finalGrade = 0.0

print("Add up all points earned for each grade topic")
print("Do not add your lowest score for the 3 topics with a dropped score(Exercise, Assignments, Quiz)\n\n")

courseGrades["Exercise"]["Earned"] = float(input("Enter your total points earned for Exercises: "))
courseGrades["Assignment"]["Earned"] = float(input("Enter your total points earned for Assignments: "))
courseGrades["Project"]["Earned"] = float(input("Enter your total points earned for Projects: "))
courseGrades["Quiz"]["Earned"] = float(input("Enter your total points earned for Quizs: "))
courseGrades["Exam"]["Earned"] = float(input("Enter your total points earned for Exams: "))
courseGrades["Final"]["Earned"] = float(input("Enter your total points earned for Finals: "))

courseGrades["Exercise"]["Grade"] = (round(courseGrades['Exercise']['Earned'] /
                                           courseGrades['Exercise']['Total'] * courseGrades['Exercise']['Weight'], 2))

courseGrades["Assignment"]["Grade"] = round(courseGrades['Assignment']['Earned'] /
                                            courseGrades['Assignment']['Total'] * courseGrades['Assignment']['Weight'],
                                            2)

courseGrades["Project"]["Grade"] = round(courseGrades['Project']['Earned'] /
                                         courseGrades['Project']['Total'] * courseGrades['Project']['Weight'], 2)

courseGrades["Quiz"]["Grade"] = round(courseGrades['Quiz']['Earned'] /
                                      courseGrades['Quiz']['Total'] * courseGrades['Quiz']['Weight'], 2)

courseGrades["Exam"]["Grade"] = round(courseGrades['Exam']['Earned'] /
                                      courseGrades['Exam']['Total'] * courseGrades['Exam']['Weight'], 2)

courseGrades["Final"]["Grade"] = round(courseGrades['Final']['Earned'] /
                                       courseGrades['Final']['Total'] * courseGrades['Final']['Weight'], 2)

os.system("cls")

print("grade Information:")

print(f"{'Category': <14} |{'PtsEarned': >10} |{'Total Pts': >10} |{'Weight':>7} |{'Grade': >6} |")
print("---------------------------------------------------------")
print((f"{'Exercise': <14} |{courseGrades['Exercise']['Earned']: >10} |"
       f"{courseGrades['Exercise']['Total']: >10} |{courseGrades['Exercise']['Weight']: >7}"
       f" |{courseGrades['Exercise']['Grade']: >6} |"))
print((f"{'Assignment': <14} |{courseGrades['Assignment']['Earned']: >10} |"
       f"{courseGrades['Assignment']['Total']: >10} |{courseGrades['Assignment']['Weight']: >7}"
       f" |{courseGrades['Assignment']['Grade']: >6} |"))
print((f"{'Project': <14} |{courseGrades['Project']['Earned']: >10} |"
       f"{courseGrades['Project']['Total']: >10} |{courseGrades['Project']['Weight']: >7}"
       f" |{courseGrades['Project']['Grade']: >6} |"))
print((f"{'Quiz': <14} |{courseGrades['Quiz']['Earned']: >10} |"
       f"{courseGrades['Quiz']['Total']: >10} |{courseGrades['Quiz']['Weight']: >7}"
       f" |{courseGrades['Quiz']['Grade']: >6} |"))
print((f"{'Exam': <14} |{courseGrades['Exam']['Earned']: >10} |"
       f"{courseGrades['Exam']['Total']: >10} |{courseGrades['Exam']['Weight']: >7}"
       f" |{courseGrades['Exam']['Grade']: >6} |"))
print((f"{'Final': <14} |{courseGrades['Final']['Earned']: >10} |"
       f"{courseGrades['Final']['Total']: >10} |{courseGrades['Final']['Weight']: >7}"
       f" |{courseGrades['Final']['Grade']: >6} |"))

finalGrade = (courseGrades["Exercise"]["Grade"] + courseGrades["Assignment"]["Grade"] + courseGrades["Project"]["Grade"]
              + courseGrades["Quiz"]["Grade"] + courseGrades["Exam"]["Grade"] + courseGrades["Final"]["Grade"])

print(f"\n\nFinal Grade: {finalGrade: .2f}")
