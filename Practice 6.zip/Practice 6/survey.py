# Orest Sosnicki, CIS345, 12:00, PE6
import random
import statistics

categories = []
entries = []


def count_up(end):
    """Yield numbers starting at 1 that count up to and including the end."""
    n = 1
    while n <= end:
        yield n
        n = n + 1


def generate_surveys(number):
    """We will simulate steps 2 and 3 and generate and process surveys <number> times"""
    for survey in range(number):
        ratings = list()
        for category in categories:
            ratings.append(random.randint(0, 5))
        score = list(zip(categories, ratings))
        filtered_score = (s for s in score if s[1] != 0)

        yield filtered_score


amount = input("How many categories do you wanted rated for your restaurant: ")

count = count_up(int(amount))

print()

for c in count:
    categories.append(input(f"Category {c}: "))

print(categories)
filtered_categories = list(filter(None, categories))
print(filtered_categories)


categories = ["Food", "Quality", "Value", "Service", "Staff", "Ambiance"]


print("On a scale of low being 1 to 5 being high")
print("rate your service in the following categories")

for c in categories:
    rating = input(f"{c}: ")
    entries.append(int(rating))

print(entries)


entries = {"2", "3", "4", "5", "0", "5"}

rating = map(int, entries)

restaurant_score = list(zip(categories, rating))

print(restaurant_score)

f = []


for d in restaurant_score:
    """d is a tuple where d[0] is Staff and d{1} is 0"""
    if d[1] != 0:
        f.append(d)

restaurant_filtered_score = [d for d in restaurant_score if d[1] != 0]

print(restaurant_filtered_score)

surveys = generate_surveys(100)


lambda x: dict(x)

results = map(lambda x: dict(x), surveys)

sums = {c: 0 for c in categories}
lengths = {c:0 for c in categories}

for survey in results:
    print("Avg rating: {}".format((statistics.mean(survey.values()))))
    for cat in categories:
        try:
            sums[cat] += survey[cat]
            lengths[cat] += 1
        except KeyError:
            pass

print("\nAverage Rating per Category:")

for cat in categories:
    print(f"{cat}: {sums[cat] / lengths[cat]:.4f} ")

