# Orest Sosnicki, CIS345, 12:00, PE4

# os allows us to clear the screen in a actual console or terminal
import os
import json
# TODO: Add imports for json


# TODO:  Read customers data file into accounts
# use the open command to open the file
# read the file and load the data structure in using json.loads()
# close the file when done
# Read File without using 'with' keyword
# Replace the below line and assign accounts data from file

fileHandle = open("customers.json")
accounts = json.load(fileHandle)
# accounts = {'9999': {'Name': 'Jill Jones', 'C': 428.78, 'S': 3062.31}}
# '1234': {'Name': 'Brit Masters', 'C': 8.62, 'S': 922.07}}
fileHandle.close()

# Allow 3 invalid pin entries
tries = 1
maxTries = 3

while tries <= maxTries:
    # Print bank title and menu
    print(f'{"Cactus Bank":^30}\n')
    selection = input('Enter pin or x to exit application: ').casefold()

    # determine exit, pin not found, or correct pin found
    if selection == 'x':
        break
    # Verify entered pin is a key in accounts
    elif selection not in accounts.keys():
        # clear screen - cls for windows and clear for linux or os x
        os.system('cls')
        # os.system('clear') for mac users

        print(f'Invalid pin. Attempt {tries} of {maxTries}. Please Try again')
        if tries == maxTries:
            print('Locked out!  Exiting program')

        tries += 1
    else:
        # Successful pin entry. reset tries and save pin
        tries = 1
        pin = selection

        os.system('cls')
        # os.system('clear')

        # Welcome customer
        print(f"Welcome {accounts[pin]['Name']}")
        print(f'{"Select Account": ^20}')

        # Prompt for Checking or Savings
        while True:
            try:
                selection = input('Enter C or S for (C)hecking or (S)avings: ').upper()
                if selection != 'C' and selection != 'S':
                    raise ValueError('Incorrect selection.  You must enter C or S.')
            except ValueError as ex:
                print(ex)
            else:
                os.system('cls')
                print(f'Opening {selection} Account...\n')
                break
        # End Prompt Checking or Savings

        print('Transaction instructions:')
        print(' - Withdrawal enter a negative dollar amount: -20.00.')
        print(' - Deposit enter a positive dollar amount: 10.50')

        # FIXME: Modify formatting to add commas for thousands
        print(f'\nBalance:  ${accounts[pin][selection]: ,.2f}')

        amount = 0.00
        try:
            amount = float(input(f'Enter transaction amount: '))
        # FIXME: Catch appropriate exceptions not Exception and
        # print better error message details using exception object
        except ValueError or TypeError as ex:
            print(ex)
            amount = 0.00

        # Verify enough funds in account
        if (amount + accounts[pin][selection]) >= 0:
            # FIXME: round() new account balance to 2 decimal places
            # Do this step last after running your program.
            accounts[pin][selection] = round((accounts[pin][selection] + amount), 2)
            # FIXME: Modify formatting to add commas for thousands
            print(f'Transaction complete. New balance is {accounts[pin][selection]: ,.2f}')
        else:
            print('Insufficient Funds. Transaction Cancelled.')

# end of application loop

print('\n\nSaving data...')
# TODO: Write accounts data structure to file
# We can write accounts to our data file here because
# this is after we exit our application loop when
# the user typed x to exit.
fileHandle = open("customers.json")
with open("customers.json", "w") as fileHandle:
    json.dump(accounts, fileHandle)


print('\nData Saved.\nExiting...')
