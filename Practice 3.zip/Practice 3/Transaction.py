# Orest Sosnicki, CIS345, 12:00, P3

# os allows us to clear the screen in a actual console or terminal
import os

# TODO: Create data structure use dictionary
# key = pin, value = account data dictionary
accounts = {'9999': {"Name": "John Doe", "C": 1.00, "S": 25.50}, "1111": {"Name": "Bob", "C": 100.0, "S": 4.0},
            '2222': {"Name": "Sam", "C": 20.0, "S": 5.}}

# FIXME: Replace names with the data structure above
# comment 2 lines below, but rename account to accounts first
# accounts = 1000.00
# pin = '9999'

# Allow 3 invalid pin entries
tries = 1
maxTries = 3

while tries <= maxTries:
    # Print bank title and menu
    print(f'{"Cactus Bank":^30}\n')
    selection = input('Enter pin or x to exit application: ').casefold()

    # determine exit, pin not found, or correct pin found
    if selection == 'x':
        break
    # FIXME: Verify entered pin in selection is a key in accounts
    elif selection not in accounts.keys():
        # clear screen - cls for windows and clear for linux or os x
        os.system('cls')
        # os.system('clear')

        print(f'Invalid pin. Attempt {tries} of {maxTries}. Please Try again')
        if tries == maxTries:
            print('Locked out!  Exiting program')
        # increment tries
        tries += 1
    else:
        # Upgrade: successful pin entry. reset tries and save pin
        tries = 1
        pin = selection

        # clear screen
        os.system('cls')

        # TODO: Welcome customer
        print(f"Welcome {accounts[pin]['Name']}")
        # Display Welcome <Customer Name>
        # accounts[pin] holds a dictionary where 'Name' is the key
        # to the customer's name value


        # TODO: Add prompt for Checking or Savings
        # Entry must be C or S to use as a key for the account balances
        # Use a loop and exception handling to ensure input is good
        # reuse selection name to store input to avoid scope issues

        # Upgrade: Removed slicing and w/d entry - New Instructions
        print('Transaction instructions:')
        print(' - Withdrawal enter a negative dollar amount: -20.00.')
        print(' - Deposit enter a positive dollar amount: 10.50')

        # Upgrade: removed for loop only 1 transaction per pin input

        while selection != "x":
            try:
                selection = input("Enter C for Checking or S for Saving ").upper()

                if selection != 'C' and selection != "S":
                    raise ValueError('Incorrect Selection. You must enter C or S.')

            except ValueError as ex:
                print(ex)

            else:
                os.system('cls')
                print(f"Opening {selection} Account")
                break

        # FIXME: All references to account need to be fixed
        # accounts is the new dictionary that needs to be indexed
        # using the entered pin and the selection account type
        print(f'\nBalance:  ${accounts[pin][selection]: .2f}')

        # TODO: Add exception handling for user entry of amount
        # Good input - convert to float and store in amount
        # Exception - Print Bad Amount and set amount to zero
        amount = float()
        try:
            amount = float(input(f'Enter transaction amount: '))
        except ValueError:
            print('Bad Amount - No Transaction')
            amount = 0.0

        # Upgrade: Verify enough funds in account
        # FIXME: All references to account need to be fixed
        # add indices for pin and selection holding account type
        if (amount + accounts[pin][selection]) >= 0:
            accounts[pin][selection] += amount
            print(f'Transaction complete. New balance is {accounts[pin][selection]: .2f}')
        else:
            print('Insufficient Funds. Transaction Cancelled.')

# end of application loop
