# Orest Sosnicki, CIS345, 12:00, A3
from functools import wraps
import difflib


def cutomer_decorator(gen):
    """outer function"""

    keep = gen()

    @wraps(gen)
    def wrapper(*args, **kwargs):
        """Wrapper"""

        gen(*args, **kwargs)
        loop = next(keep)
        return f"Question {loop}"

    return wrapper


@cutomer_decorator
def question_number():
    number = 1
    while True:
        yield number
        number += 1


def get_question(path):
    with open(path) as file:
        for q in file:
            split1 = q.split("\n")
            split2 = split1[0].split(",")
            yield split2


def grade_question(enter, answer):
    ratio = difflib.SequenceMatcher(None, enter, answer).ratio()
    return ratio


title = "Movie Trivia"

print(f"{title:*^30}")
print("\nYou will be given a character and you must respond with their movie: ")

trivia = get_question("questions.txt")

points = 0
total = 11

for question in trivia:
    number = question_number()
    entered = input(f"{number} {question[0]}: ").casefold()

    calculate_ratio = grade_question(entered, question[1])
    if calculate_ratio > .70:
        points += 1

print(f"you scored {points} out of {total} questions")
