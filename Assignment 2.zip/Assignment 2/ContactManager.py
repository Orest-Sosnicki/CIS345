# Orest Sosnicki, CIS345, 12:00, A2

from difflib import get_close_matches
import os
import json

contacts = dict

name = ""
newContact = ""
changeContact = ""

try:
    with open("contacts.json", "r") as file:
        contacts = json.load(file)

except IOError or FileNotFoundError as ex:
    print(ex)

finally:
    for key, value in contacts.items():
        print(f"{key: <15} - {value}")
    print("Data loaded. Press enter to continue ")

while name != "e":
    listResults = dict
    check = False
    loopCount = 1

    print("\t\tManager Contacts")
    name = input("Enter a name you want to search for: ").capitalize()
    print("")
    searchResults = get_close_matches(name, contacts, n=5, cutoff=.2)

    for results in searchResults:

        check = False
        if name == results:
            print("Contact found: ")
            print("Edit Contact")
            print(f"{results: <10}:{contacts[name]}")

            while True:
                changeContact = input(f"\nEnter {name}'s phone number (###) ###-#### or enter nothing for no change: ")
                if len(changeContact) == 13:
                    contacts[name] = changeContact
                    break
                elif len(changeContact) == 0:
                    break
                else:
                    print("Invalid input, You must enter a number formatted like this '(###)###-####' try again:")
            break
        elif len(searchResults) > 1:

            if loopCount == 1:
                print("Contacts Found")
                loopCount += 1
            print(f"{results: <10}:{contacts[results]}")

        else:
            check = True

    if check:
        print("Contact not found")
        print("Add New Contact")
        newContact = input(f"\nEnter {name}'s phone number (###)###-#### or enter for no change: ")
        if len(newContact) == 0:
            newContact = ""
        contacts[name] = newContact

    os.system("cls")
    name = input("Enter E to exit or press enter to continue: ").casefold()

newFile = open("contacts.json", "w")
json.dump(contacts, newFile)
newFile.close()

