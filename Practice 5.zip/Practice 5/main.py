# Orest Sosnicki, CIS345, 12:00, PE5

import utilities


def divide(numerator, denominator):
    # divides two numbers entered
    answer = 0
    try:
        answer = numerator / denominator
        return answer
    except ZeroDivisionError as exceptionData:
        print(f"Error: {exceptionData}. Can't divide by 0")


def average(*values):
    # Find the average of the entered numbers
    total = 0
    for value in values:
        total += value

    return total / len(values)


def factorial(number):
    # find the factorial of the number entered
    if number == 1:
        return number
    return factorial(number - 1) * number


def employee_profile(**kwargs):
    #
    print(utilities.what_type(kwargs))
    utilities.header("Profile")
    for key, value in kwargs.items():
        print(f"{key: <15} | {value}: >15")

    return None




utilities.header("divide")
print(f"10 / 5 is: {divide(10, 5)}")

print(f"10 / 0 is: {divide(10, 0)}")

utilities.header("average")
print(f"Average of 1-10: {average(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)}")

utilities.header("factorial")
print(f"Factorial 5! = {factorial(5)}")
print(f"Factorial 7! = {factorial(7)}")
print(f"Factorial 9! = {factorial(9)}")

utilities.header("employee_profile")
print()
employee_profile(Name="Michael Crow", Position="president", Status="Active", Salary="$1,351,903,72")
