# Orest Sosnicki, CIS345, 12:00, PE5
def header(name):
    # creates a header centered between *
    print(f"{name:*^30}")


def what_type(item):
    # Return the type of the variable you but in
    return str(type(item))


testVariable = 10.5

if __name__ == "__main__":
    header("Test Program")
    what_type(testVariable)
