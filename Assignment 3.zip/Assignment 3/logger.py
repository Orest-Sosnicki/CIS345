# Orest Sosnicki, CIS345, 12:00, A3
import csv


def log_transactions(values):
    loopOne = 5
    loopTwo = 0

    row = list()
    with open("Log.csv", "w", newline="") as fw:
        write = csv.writer(fw)
        while loopOne < len(values):

            while loopTwo < loopOne:

                row.append(values[loopTwo])
                loopTwo += 1
            loopOne += 5
            write.writerow(row)
            row = list()


def format_money(number=float()):
    money = f"${number: ,.2f}"
    return money

