# Orest Sosnicki, CIS345, 12:00

from tkinter import *
import math


def number(num):
    global hold_one, text, dec

    if num == "0" or num == "1" or num == "2" or num == "3" or num == "4" or num == "5" or num == "6" \
            or num == "7" or num == "8" or num == "9":
        hold_one = hold_one + num
        text.set(hold_one)

    elif num == "." and dec is False:
        dec = True
        hold_one = hold_one + num
        text.set(hold_one)


def equation(option):
    global hold_one, dec, switch, used

    if option == "1":
        hold_one = hold_one + "+"
        text.set(hold_one)
        dec = False
    if option == "2":
        hold_one = hold_one + "-"
        text.set(hold_one)
        dec = False
    if option == "3":
        hold_one = hold_one + "*"
        text.set(hold_one)
        dec = False
    if option == "4":
        hold_one = hold_one + "/"
        text.set(hold_one)
        dec = False
    if option == "5":
        hold_one = str(float(math.sqrt(eval(hold_one))))
        text.set(hold_one)
    if option == "6":

        if switch is False:
            if used >= 1:
                hold_one = hold_one[1:]
            hold_one = "-" + hold_one
            text.set(hold_one)
            switch = True
        else:
            hold_one = hold_one[1:]
            hold_one = "+" + hold_one
            text.set(hold_one)
            switch = False
            used = used + 1
    if option == "7":
        try:
            text.set(str(eval(hold_one)))
            answer = str(eval(hold_one))
            hold_one = answer
            used = 0
            switch = False
            dec = False
        except SyntaxError as error:
            print("You entered a invalid equation " + error)
        except TypeError as diff:
            print("You entered a invalid equation " + diff)
        except ZeroDivisionError as zero:
            text.set("Error")
            hold_one = ""


def clear(input):
    global hold_one, text

    if input == "1":
        hold_one = ""
        text.set("")

    if input == "2":
        hold_one = hold_one[:len(hold_one) - 1]
        text.set(hold_one)


def back():
    global hold_one

    hold_one[:1]


hold_one = str()
dec = False
switch = False
used = 0

view = Tk()

button_collor = "orange"

button_width = 5
text = StringVar()
text.set("")

view.geometry("300x500")
view.title("Calculator")
view.pack_propagate(0)
view.config(background="skyblue")

# row 0 ---------------------------------------------------------------------

output = Entry(view, textvariable=text, width=30, justify=RIGHT, state="disabled")
output.grid(row=0, column=0, columnspan=4)

# row 1 ---------------------------------------------------------------------

c_button = Button(view, text="C", width=button_width, command=lambda: clear("1"), bg="green")
c_button.grid(row=1, column=0)

back_button = Button(view, text="←", width=button_width, command=lambda: clear("2"), bg="light green")
back_button.grid(row=1, column=1)

plusminus_button = Button(view, text="±", width=button_width, command=lambda: equation("6"), bg="light green")
plusminus_button.grid(row=1, column=2)

squr_button = Button(view, text="√", width=button_width, command=lambda: equation("5"), bg="light green")
squr_button.grid(row=1, column=3)

# row 2 ----------------------------------------------------------------------

seven_button = Button(view, text="7", width=button_width, command=lambda: number("7"), bg=button_collor)
seven_button.grid(row=2, column=0)

eight_button = Button(view, text="8", width=button_width, command=lambda: number("8"), bg=button_collor)
eight_button.grid(row=2, column=1)

nine_button = Button(view, text="9", width=button_width, command=lambda: number("9"), bg=button_collor)
nine_button.grid(row=2, column=2)

divide_button = Button(view, text="÷", width=button_width, command=lambda: equation("4"), bg=button_collor)
divide_button.grid(row=2, column=3)

# row 3 ----------------------------------------------------------------------

four_button = Button(view, text="4", width=button_width, command=lambda: number("4"), bg=button_collor)
four_button.grid(row=3, column=0)

five_button = Button(view, text="5", width=button_width, command=lambda: number("5"), bg=button_collor)
five_button.grid(row=3, column=1)

six_button = Button(view, text="6", width=button_width, command=lambda: number("6"), bg=button_collor)
six_button.grid(row=3, column=2)

multiply_button = Button(view, text="X", width=button_width, command=lambda: equation("3"), bg=button_collor)
multiply_button.grid(row=3, column=3)

# row 4 ----------------------------------------------------------------------

one_button = Button(view, text="1", width=button_width, command=lambda: number("1"), bg=button_collor)
one_button.grid(row=4, column=0)

two_button = Button(view, text="2", width=button_width, command=lambda: number("2"), bg=button_collor)
two_button.grid(row=4, column=1)

three_button = Button(view, text="3", width=button_width, command=lambda: number("3"), bg=button_collor)
three_button.grid(row=4, column=2)

minus_button = Button(view, text="-", width=button_width, command=lambda: equation("2"), bg=button_collor)
minus_button.grid(row=4, column=3)

# row 5 ----------------------------------------------------------------------

zero_button = Button(view, text="0", width=button_width, command=lambda: number("0"), bg=button_collor)
zero_button.grid(row=5, column=0)

period_button = Button(view, text=".", width=button_width, command=lambda: number("."), bg=button_collor)
period_button.grid(row=5, column=1)

equals_button = Button(view, text="=", width=button_width, command=lambda: equation("7"), bg="dark red")
equals_button.grid(row=5, column=2)

plus_button = Button(view, text="+", width=button_width, command=lambda: equation("1"), bg=button_collor)
plus_button.grid(row=5, column=3)

view.mainloop()
