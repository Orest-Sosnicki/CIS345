# Orest Sosnicki, CIS345, 12:00
from socket import *

HOST = "127.0.0.1"
PORT = 60000
ADDR = (HOST, PORT)

server = socket(AF_INET, SOCK_STREAM)
server.connect(ADDR)
server.send("Orest".encode())
received = server.recv(1024)
server.close()
print(received.decode())
