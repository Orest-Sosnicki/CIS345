# Orest Sosnicki, CIS345, 12:00
from socket import *
from time import ctime

HOST = "127.0.0.1"
PORT = 60000
ADDR = (HOST, PORT)
BUFSIZE = 1024
count = 0

server = socket(AF_INET, SOCK_STREAM)
server.bind(ADDR)
server.listen(5)
print("server has started and listening on")
print(ADDR)

while True:
    client, address = server.accept()
    count += 1
    name = client.recv(BUFSIZE)
    connection = f"Connection {count} from {name.decode()} - {address}"
    time = f"Cureent time {ctime()} and Goodbye"
    client.send(f"{connection} \n{time}".encode())
