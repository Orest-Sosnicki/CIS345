# Orest Sosnicki, CIS345, 12:00, PE1
import os


account = 1000.00
pin = '9999'
tries = 1
maxTries = 3

while tries <= 3:
    print(f'{"Cactus Bank" :^30}\n')
    selection = input("Enter pin or x to exit the application: ").casefold()

    if selection == 'x':
        break
    elif selection != pin:
        os.system('cls')
        print(f"Invalid pin. Attempt {tries} of {maxTries}. Please Try again")
        if tries == maxTries:
            print("Looked out! Exiting program")
        tries += 1
    else:
        tries = 1
        print("Transaction instructions:")
        print("Enter w for Withdrawal or d Deposit followed by dollar amount.")
        print("Example withdrawal of 10.50 you enter w10.50")
        print("All dollar amounts must be positive numbers")

        for num in range(1, 5):
            print(f"\nBalance: ${account :.2f}")
            selection = input(f"Enter transaction {num}: ")
            print(f"Starting balance is {account :.2f}")

            transaction = selection[0:1].casefold()
            if (transaction[0:1] == 'w' and account >= float(selection[1:]) >= 0 and
                    len(selection) > 1):
                account -= float(selection[1:])
                print(f"After Withdrawal new balance is {account :.2f}")
            elif transaction[0:1] == 'd' and float(selection[1:]) >= 0 and len(selection) > 1:
                account += float(selection[1:])
                print(f"After Deposit new balance is {account :.2f}")
            else:
                print("you did not enter a proper Transaction, try again")

        print("\nEnd of Transactions")
        print("\nExiting application")
        break
