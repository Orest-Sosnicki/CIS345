# Orest Sosnicki, CIS345, 12:00, PE6
import random
import os

courses = []


class Course:
    # class variables
    semester = 'Fall 2025'

    def __init__(self, name='', categories=None):
        """Create a course object. self refers to the object"""
        self.section = random.randint(10000, 100000)
        self.name = name
        self.student_count = 0
        self.class_roster = []
        if categories is None:
            self.categories = []
        else:
            self.categories = categories

    # Instance variable categories will hold a description and total point value
    # TODO: Add decision for categories=None based on Requirements to avoid mutable trap

    @classmethod
    def change_semester(cls, semester):
        """Modify the text of the semester that all courses are being added to"""
        cls.semester = semester

    # TODO: Add enter_categories method to accept all categories for a course

    def enter_categories(self):
        print(f"enter grading categories for {course_name} ")
        while True:
            acronym = input("Enter a 5 letter acronym for each grading category: ")
            points = int(input(f"Enter points earned for {acronym}"))
            self.categories[acronym] = points
            more = input("do you have more categories to enter(Y/N").upper()
            os.system("cls")
            if more == "N":
                break

    # TODO: Add method to enroll_students in course
    def enroll_students(self, number):
        self.student_count += number
        for n in range(number):
            temp_student = Student(self.categories)
            temp_student.fullname = input("enter student first and last name: ")
            temp_student.enter_scores()
            self.class_roster.append(temp_student)

    # TODO: Override __str__ method for course to print roster and scores
    def __str__(self):
        message = f'Course {self.section} - {self.name} has {self.student_count} students: \n'
        for n in self.class_roster:
            message += f" \n{n.fullname} - "
            for c in self.categories:
                message += f"{c}: {c.scores[self.categories]} / {self.categories[c]}"
        return message


# TODO: Create student class per UML
class Student:

    def __init__(self, categories=None, fname="Jane", lname="Doe"):
        self.first = fname
        self.last = lname
        if categories is None:
            self.categories = []
        else:
            self.categories = categories

    @property
    def fullname(self):
        return f"{self.first}, {self.last}"

    @fullname.setter
    def fullname(self, name):
        self.first, self.last = name.split(' ')

    def __str__(self):
        return self.fullname

    def enter_scores(self):
        for c in self.categories:
            score = int(input(f"enter earned points for {c}: "))
            self.categories[c] = score


# Main Logic
print('{:*^30}'.format('University System'))
Course.change_semester(input('Enter semester and year for which you are creating courses: '))

enter_courses = 'y'
# Below 3 lines is test data to avoid user input - you may use to speed up development or not.
# test_cats = {'PE': 10, 'Assignment': 30, 'Quiz': 20, 'Exam': 100}
# course1 = Course('CIS345', test_cats)
# courses.append(course1)
print("\nEntering course information")
while enter_courses == 'y':
    course_name = input('Enter course name: ').upper()
    new_course = Course(course_name)
    courses.append(new_course)
    enter_courses = input("\nAdd another course (Y/N)? ").casefold()

# Add students to each course using enroll_students()
os.system('cls')
# TODO: Create logic to add students to each course using methods created within classes

for n in courses:
    print(f"\nadd students to {n.name} course")
    enroll = int(input("how many students do you want to enroll: "))
    n.enroll_students(enroll)

# Print Course Roster using Override methods to quickly display necessary data
os.system('cls')
print("\nCourse Information for {}".format(Course.semester))
# TODO: Create logic to print each courses student roster

for c in courses:
    print(c)
