# Orest Sosnicki, CIS345, 12:00, A5


class Employee:
    def __init__(self, name=" ", eid=""):
        self.__name = name
        self.__eid = eid

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        if name.isalpha():
            self.__name = name.capitalize()
        else:
            self.__name = "Unknow"

    @property
    def eid(self):
        return self.__eid

    @eid.setter
    def eid(self, eid):
        if len(eid) == 0:
            self.__eid = "9999"
        else:
            self.__eid = eid.zfill(4)

    def __str__(self):
        return f"{self.__eid.zfill(4)}: {self.__name.capitalize()}"


class Manager(Employee):

    def __init__(self, name="", eid=""):
        super().__init__(name, eid)
        self.list = []
        if list is None:
            self.list = list()

    def add_subordinates(self):
        sub = Employee()
        sub.name = input("Enter subordinate name: ")
        sub.eid = input("Enter subordinate id:")
        self.list.append(sub)

    def print_subordinate(self):
        for l in self.list:
            print(f"\t{l}")


def add_employee():
    name = input("Enter name: ")
    id = input("Enter id: ")

    manager = input("Is the employee a manager? (Y/N) ").casefold()
    if manager == "y":
        new = Manager()

        number = int(input("How many subordinates? "))
        for n in range(number):
            new.add_subordinates()

        new.name = name
        new.eid = id

    else:
        new = Employee()

        new.name = name
        new.eid = id

    return new


def main():
    loop = "y"
    employees = []

    print("Employee Management System\n")

    print("Adding Employees...")

    while loop != "n":
        print()
        employees.append(add_employee())
        loop = input("Do you want to enter more? (Y/N) ").casefold()

    else:
        print("\nPrinting Employee List")

        for n in employees:
            print(n)
            if isinstance(n, Manager):
                print(f"\t{n.name}'s Employees")
                for l in n.list:
                    print(f"\t{l}")


if __name__ == "__main__":
    main()