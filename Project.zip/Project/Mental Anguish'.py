from tkinter import *
from random import randint
from difflib import get_close_matches


class details:
    def __init__(self, question="", choise1="", choise2="", choise3="", choise4="", correct="", incorrect="", right="",
                 points=""):
        self.__question = question
        self.__choise1 = choise1
        self.__choise2 = choise2
        self.__choise3 = choise3
        self.__choise4 = choise4
        self.__correct = correct
        self.__incorrect = incorrect
        self.__right = right
        self.__points = points

    @property
    def correct(self):
        return self.__correct

    @correct.setter
    def correct(self, corr):
        self.__correct = f"Correct: " + corr

    @property
    def incorrect(self):
        return self.__incorrect

    @incorrect.setter
    def incorrect(self, incorr):
        self.__incorrect = "Incorrect: " + incorr

    @property
    def right(self):
        return self.__right

    @right.setter
    def right(self, answer):
        self.__right = f"Answer: " + answer

    def __str__(self):
        return f"{self.__question},{self.__choise1},{self.__choise2},{self.__choise3},{self.__choise4}," \
               f"{self.__correct},{self.__incorrect},{self.__right},{self.__points}"


def ReplaceFrame():
    global window, frame
    frame.destroy()
    frame = Frame(window)
    frame.pack(side=LEFT)
    frame.config(padx=10)


def Save():
    global question_list, question_listbox, command, select
    question_listbox.delete(0, END)
    question_list = list()
    file = "Questions"
    with open(file, "r") as fp:
        for n in fp:
            question_list.append(n.strip())
            hold = n.split(",")[0]
            question_listbox.insert(END, hold)

    select = ""
def View_questions():
    global window, frame, question_listbox, command, entry_list

    size = 40

    ReplaceFrame()
    question_listbox = Listbox(frame, width=70, height=6)
    question_listbox.grid(row=0, column=0, columnspan=2)
    question_listbox.bind("<Double-Button-1>", Edit)

    l_question = Label(frame, text="Question:", font='Helvetica 10 bold')
    l_question.grid(row=1, column=0, sticky=E)
    e_question = Entry(frame, textvariable=text_list[0], width=size)
    e_question.grid(row=1, column=1)

    l_choise1 = Label(frame, text="Choise1:", font='Helvetica 10 bold')
    l_choise1.grid(row=2, column=0, sticky=E)
    e_choise1 = Entry(frame, textvariable=text_list[1], width=size)
    e_choise1.grid(row=2, column=1)

    l_choise2 = Label(frame, text="Choise2:", font='Helvetica 10 bold')
    l_choise2.grid(row=3, column=0, sticky=E)
    e_choise2 = Entry(frame, textvariable=text_list[2], width=size)
    e_choise2.grid(row=3, column=1)

    l_choise3 = Label(frame, text="Choise3:", font='Helvetica 10 bold')
    l_choise3.grid(row=4, column=0, sticky=E)
    e_choise3 = Entry(frame, textvariable=text_list[3], width=size)
    e_choise3.grid(row=4, column=1)

    l_choise4 = Label(frame, text="Choise4:", font='Helvetica 10 bold')
    l_choise4.grid(row=5, column=0, sticky=E)
    e_choise4 = Entry(frame, textvariable=text_list[4], width=size)
    e_choise4.grid(row=5, column=1)

    l_correct_r = Label(frame, text="Correct Response:", font='Helvetica 10 bold')
    l_correct_r.grid(row=6, column=0, sticky=E)
    e_correct_r = Entry(frame, textvariable=text_list[5], width=size)
    e_correct_r.grid(row=6, column=1)

    l_incorrect_r = Label(frame, text="Incorrect Response:", font='Helvetica 10 bold')
    l_incorrect_r.grid(row=7, column=0, sticky=E)
    e_incorrect_r = Entry(frame, textvariable=text_list[6], width=size)
    e_incorrect_r.grid(row=7, column=1)

    l_correct_a = Label(frame, text="Correct Answer:", font='Helvetica 10 bold')
    l_correct_a.grid(row=8, column=0, sticky=E)
    e_correct_a = Entry(frame, textvariable=text_list[7], width=size)
    e_correct_a.grid(row=8, column=1)

    l_points = Label(frame, text="Points:", font='Helvetica 10 bold')
    l_points.grid(row=9, column=0, sticky=E)
    e_points = Entry(frame, textvariable=text_list[8], width=size)
    e_points.grid(row=9, column=1)

    command = Button(frame, text="Add Question", command=Add_question)
    command.grid(row=10, column=1)

    entry_list = [e_choise1, e_choise2, e_choise3, e_choise4, e_correct_r, e_incorrect_r,e_correct_a, e_points]

    Save()
    Clear()
    window.geometry("450x350")


def Add_question():
    global text_list, command, question_list, select, question_listbox

    question_add = details(text_list[0].get(), text_list[1].get(), text_list[2].get(), text_list[3].get(),
                           text_list[4].get(), text_list[5].get(), text_list[6].get(), text_list[7].get(),
                           text_list[8].get())

    if command["text"] == "Add Question":

        question_list.append(question_add)

        file = open("Questions", "w")
        for n in question_list:
            file.write(f"{n}\n")
        file.close()

    elif command["text"] == "Edit Question":

        question_list[select] = question_add
        file = open("Questions", "w")
        for n in question_list:
            file.write(f"{n}\n")
        file.close()

    elif command["text"] == "Delete Question":

        question_list.remove(question_list[select])
        file = open("Questions", "w")
        for n in question_list:
            file.write(f"{n}\n")
        file.close()

    elif command["text"] == "Search Question":
        question_listbox.delete(0, END)
        hold_question_list = []

        if text_list[0].get() != "":
            for n in question_list:
                hold_question_list.append(n.split(",")[0])
            search = text_list[0].get()

            print(search)
            print(hold_question_list)
            search_list = get_close_matches(search, hold_question_list)

            for n in search_list:
                question_listbox.insert(END, n)

        return ""

    Save()
    Clear()


def Edit(event):
    global question_list, question_listbox, text_list, command, select

    select = question_listbox.curselection()
    select = select[0]
    for n in range(0, 9):
        hold = question_list[select].split(",")[n]

        text_list[n].set(hold)


def Clear():
    global text_list

    for n in range(0, 9):
        text_list[n].set("")


def Edit_Mode():
    global command

    View_questions()

    command["text"] = "Edit Question"


def Delete_Mode():
    global command

    View_questions()

    command["text"] = "Delete Question"


def Search_Mode():
    global command, question_listbox, entry_list

    View_questions()
    question_listbox.delete(0, END)

    command["text"] = "Search Question"

    for n in range(0, 8):
        entry_list[n]["state"] = "disabled"


def View_Game():
    global game_list, game_enter, question_text, next_question, points_total, points_possible, correct_answer
    ReplaceFrame()

    question_text = Label(frame, text=" Question 1/3: ", font='Helvetica 10 bold')
    question_text.grid(row=0, column=0, sticky=E)
    game_question = Label(frame, text="question")
    game_question.grid(row=0, column=1, sticky=W, columnspan=2)
    frame.bind("<Key>", Play_Game)

    points_possible = Label(frame, text="Points Possible", font='Helvetica 10 bold')
    points_possible.grid(row=0, column=2)

    points_total = Label(frame, text="Points: ", font='Helvetica 10 bold')
    points_total.grid(row=1, column=2)

    Choice1 = Label(frame, text="Choice 1:", font='Helvetica 10 bold')
    Choice1.grid(row=1, column=0, sticky=E)
    game_choice1 = Label(frame, text="option 1")
    game_choice1.grid(row=1, column=1, sticky=W)

    Choice2 = Label(frame, text="Choice 2:", font='Helvetica 10 bold')
    Choice2.grid(row=2, column=0, sticky=E)
    game_choice2 = Label(frame, text="option 2")
    game_choice2.grid(row=2, column=1, sticky=W)

    Choice3 = Label(frame, text="Choice 3:", font='Helvetica 10 bold')
    Choice3.grid(row=3, column=0, sticky=E)
    game_choice3 = Label(frame, text="option 3")
    game_choice3.grid(row=3, column=1, sticky=W)

    Choice4 = Label(frame, text="Choice 4:", font='Helvetica 10 bold')
    Choice4.grid(row=4, column=0, sticky=E)
    game_choice4 = Label(frame, text="option 4")
    game_choice4.grid(row=4, column=1, sticky=W)

    feedback = Label(frame, text="Feedback: ", font='Helvetica 10 bold')
    feedback.grid(row=5, column=0, sticky=E)
    game_feedback = Label(frame, text="")
    game_feedback.grid(row=5, column=1, sticky=W)

    correct = Label(frame, text="Correct Choice: ", font='Helvetica 10 bold')
    correct.grid(row=6, column=0, sticky=E)
    correct_answer = Label(frame, text="")
    correct_answer.grid(row=6, column=1, sticky=W)

    game_play = Label(frame, text="Enter 1, 2, 3 or 4 in the box to make a guess")
    game_play.grid(row=7, column=1, sticky=E)
    game_enter = Entry(frame, width=2)
    game_enter.grid(row=7, column=2, sticky=W)
    game_enter.bind("<Key>", Play_Game)

    next_question = Button(frame, text="Next Question", command=Next_Question)
    next_question.grid(row=8, column=1)

    game_list = [game_question, game_choice1, game_choice2, game_choice3, game_choice4, game_feedback]

    Load_Game()
    window.geometry("490x210")


def Load_Game():
    global question_list, game_list, game_question, count, next_question, total_points, earned_points, points_total, \
        newgame, points_possible, random_list, random

    points_total["text"] = f"Points {earned_points}/{total_points}"
    if newgame:
        next_question["state"] = "normal"
        total_points = 0
        earned_points = 0
        points_total["text"] = f"Points {earned_points}/{total_points}"
        random_list = []

    random = randint(0, len(question_list) - 1)
    while random in random_list:
        random = randint(0, len(question_list) - 1)

    random_list.append(random)
    game_question = question_list[random]

    for n in range(0, 5):
        hold = game_question.split(",")[n]
        game_list[n]["text"] = hold
    newgame = False
    points_possible["text"] = f"Points Possible: {game_question.split(',')[8]}"

    total_points += int(game_question.split(",")[8])
    points_total["text"] = f"Points {earned_points}/{total_points}"

    next_question["state"] = "disabled"

def Play_Game(event):
    global game_enter, question_list, game_question, game_list, total_points, earned_points, points_total, \
        points_possible, next_question
    valid_keys = ["1", "2", "3", "4"]
    if event.char in valid_keys:
        game_enter["state"] = "disabled"
        answer = game_question.split(",")[7]
        choise = game_question.split(",")[int(event.char)]

        if answer == choise:
            game_list[5]["text"] = f"Correct: {game_question.split(',')[5]}"
            earned_points += int(game_question.split(",")[8])
        else:
            game_list[5]["text"] = f"Incorrect: {game_question.split(',')[6]}"

    points_total["text"] = f"Points {earned_points}/{total_points}"
    correct_answer["text"] = f"{answer}"

    if newgame is False:
        next_question["state"] = "normal"

def Next_Question():
    global question_text, count, game_enter, newgame, correct_answer, game_list
    Load_Game()
    count += 1
    question_text["text"] = f"Question {count}/3"

    if count == 3:
        count = 1
        newgame = True

    game_enter["state"] = "normal"
    correct_answer["text"] = ""
    game_list[5]["text"] = ""
    next_question["state"] = "disabled"



window = Tk()
window.title("Game")
window.geometry("500x400")

question_list = list()
question_listbox = list()

game_list = list()
game_enter = ""
game_question = ""
next_question = ""

question_text = ""
correct_answer = ""
count = 1

earned_points = 0
total_points = 0
entry_list = []

points_total = ""
points_possible = ""
random_list = []
raondom = 0

command = ""
select = 0

newgame = False

q_text = StringVar()
c1_text = StringVar()
c2_text = StringVar()
c3_text = StringVar()
c4_text = StringVar()
cr_text = StringVar()
inr_text = StringVar()
ca_text = StringVar()
points = StringVar()

text_list = [q_text, c1_text, c2_text, c3_text, c4_text, cr_text, inr_text, ca_text, points]

menu_bar = Menu(window)
window.config(menu=menu_bar)

file_menu = Menu(menu_bar, tearoff=False)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Exit", command=window.quit)
menu_bar.add_command(label="Add", command=View_questions)
menu_bar.add_command(label="Edit", command=Edit_Mode)
menu_bar.add_command(label="Delete", command=Delete_Mode)
menu_bar.add_command(label="Search Question", command=Search_Mode)
menu_bar.add_command(label="New Game", command=View_Game)

frame = Frame(window)
View_questions()

window.mainloop()
