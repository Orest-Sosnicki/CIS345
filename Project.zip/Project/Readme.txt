Instructions:
Click the "Add" Tab to Enable the ability to add new questions

Click the "Edit" Tab to Enable the ability to Edit questions
	Double click a question in list that you want to edit and then click the
	"Edit Questions" button at the bottom after you have made changes

Click the "Delete" Tab to Enable the ability to Delete questions
	Doulbe Click the questions you want to delete and then click the
	"Delete Questions" button at the bottom

Click the "Search Question" Tab to Enable the ability to Search for questions
	Enter the question you want to search for in the question box and then click
	"Search Questions" button at the bottom

Click the "New Game" Tab to Begain playing the Quiz
	Enter 1,2,3 or 4 in the box to make your guess: click the "Next Question"
	button to proceed to the next question
	Press "New Game" to Start a new game after 3 questions have been answered