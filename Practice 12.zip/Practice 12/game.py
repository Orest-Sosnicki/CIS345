# Orest Sosnicki, CIS345, 12:00
from tkinter import *
from tkinter import ttk
import random


def reset_game():
    global count, answer, feedback
    feedback_lbl["text"] = feedback
    guess_textBox.set("")
    count = 0
    answer = random.randrange(1, 11)
    counter_lbl['text'] = f" Guess {count} / 3"
    progress["value"] = 0
    submit_button["state"] = "normal"


def check_answer():
    global guess, count, answer

    guess = int(guess_textBox.get())
    guess_textBox.set("")
    progress["value"] += 100
    count += 1
    counter_lbl['text'] = f" Guess {count} / 3"

    if answer == guess:
        feedback_lbl["text"] = "You Win!!!!"
        submit_button["state"] = "disabled"
    elif count == 3:
        feedback_lbl["text"] = f"Answer was {answer}. You Lose!"
        submit_button["state"] = "disabled"
    elif answer < guess:
        feedback_lbl["text"] = f" {guess} is to high."
    else:
        feedback_lbl["text"] = f" {guess} is to low."


# creating the screen layout
window = Tk()

answer = int()
count = int()
feedback = "Enter guess 1"
guess = StringVar()

window.title("Guess Game")
window.geometry("250x195")
window.iconbitmap("FavoriteSpot.ico")

# creating menu bar
menu_bar = Menu(window)
window.config(menu=menu_bar)

# add to menu bar
file_menu = Menu(menu_bar, tearoff=False)
menu_bar.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="Reset", command=reset_game)
file_menu.add_command(label="Exit", command=window.quit)

# creating label
feedback_lbl = Label(window, text=feedback, justify=LEFT)

feedback_lbl.pack()

# creating entry textbox
guess_textBox = StringVar()
guess_textBox.set("")
name_entry = Entry(window, textvariable=guess_textBox, justify=RIGHT, width=25)
name_entry.pack(pady=10)

# creating progression bar
progress = ttk.Progressbar(window, orient="horizontal", length=150, maximum=301, mode="determinate")
progress.pack(pady=10)

# another label
counter_lbl = Label(window, text=count, justify=CENTER)
counter_lbl["text"] = f" Guess {count} / 3"
counter_lbl.pack()

# creating button
submit_button = Button(window, command=check_answer, text="Submit", width=20)
submit_button.pack()

# showing GUI
reset_game()
window.mainloop()
