# Orest Sosnicki, CIS345, 12:00, PE10

import turtle

turtle.setup(800,800)
window = turtle.Screen()
window.reset()


name = turtle.Turtle()

name.hideturtle()
name.speed(10)

name.turtlesize(5)
name.penup()
name.left(180)
name.forward(300)
name.pendown()
name.right(90)
name.forward(70)
name.right(90)
name.forward(50)
name.right(90)
name.forward(70)
name.right(90)
name.forward(50)

name.right(180)
name.penup()
name.forward(100)
name.pendown()
name.left(90)
name.forward(70)
name.right(90)
name.forward(50)
name.right(90)
name.forward(40)
name.right(90)
name.forward(50)
name.left(135)
name.forward(45)

name.left(45)
name.penup()
name.forward(120)
name.pendown()
name.left(180)
name.forward(50)
name.right(90)
name.forward(80)
name.right(90)
name.forward(50)
name.right(90)
name.penup()
name.forward(40)
name.pendown()
name.right(90)
name.forward(50)
name.left(180)

name.penup()
name.forward(80)
name.left(90)
name.forward(40)
name.right(90)
name.forward(50)
name.left(180)
name.pendown()
name.forward(50)
name.left(90)
name.forward(40)
name.left(90)
name.forward(50)
name.right(90)
name.forward(40)
name.right(90)
name.forward(50)

name.right(180)
name.penup()
name.forward(130)
name.pendown()
name.left(90)
name.forward(70)
name.right(90)
name.forward(35)
name.right(180)
name.forward(70)











turtle.done()

